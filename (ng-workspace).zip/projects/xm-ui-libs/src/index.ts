/*
 * 库的入口文件
 */

export * from './components/test-ui';
export * from './components/rate';
