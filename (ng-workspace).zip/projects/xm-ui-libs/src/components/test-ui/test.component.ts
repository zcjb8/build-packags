import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'xm-test',
  template: `
    <p>
      xm-ui-libs works !!!!!
    </p>
  `,
  styles: [
  ]
})
export class TestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
