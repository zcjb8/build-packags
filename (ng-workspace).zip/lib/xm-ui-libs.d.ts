/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="xm-ui-libs" />
export * from './index';
