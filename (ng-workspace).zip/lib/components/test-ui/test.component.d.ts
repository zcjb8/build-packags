import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TestComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TestComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TestComponent, "xm-test", never, {}, {}, never, never>;
}
