import * as i0 from "@angular/core";
import * as i1 from "./test.component";
export declare class TestUiModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<TestUiModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<TestUiModule, [typeof i1.TestComponent], never, [typeof i1.TestComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<TestUiModule>;
}
