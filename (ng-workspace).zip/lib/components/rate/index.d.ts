export * from './rate.component';
export * from './rate.module';
