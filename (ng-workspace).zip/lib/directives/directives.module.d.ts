import * as i0 from "@angular/core";
import * as i1 from "./icon/icon.directive";
export declare class DirectivesModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<DirectivesModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<DirectivesModule, [typeof i1.IconDirective], never, [typeof i1.IconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<DirectivesModule>;
}
