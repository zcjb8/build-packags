import { OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TestUiComponent implements OnInit {
    constructor();
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TestUiComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TestUiComponent, "raft-test-ui", never, {}, {}, never, never>;
}
