import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'raft-test-ui',
  template: `
    <p>
      test-ui works!
    </p>
  `,
  styles: [
  ]
})
export class TestUiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
