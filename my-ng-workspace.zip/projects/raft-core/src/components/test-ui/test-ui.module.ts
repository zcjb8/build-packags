import { NgModule } from '@angular/core';
import { TestUiComponent } from './test-ui.component';



@NgModule({
  declarations: [
    TestUiComponent
  ],
  imports: [
  ],
  exports: [
    TestUiComponent
  ]
})
export class TestUiModule { }
