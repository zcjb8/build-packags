import { NgModule } from '@angular/core';
import { IconDirective } from './icon/icon.directive';



@NgModule({
  declarations: [IconDirective],
  exports: [IconDirective]
})
export class DirectivesModule { }
