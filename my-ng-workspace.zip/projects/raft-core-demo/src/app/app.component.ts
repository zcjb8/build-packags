import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
   <div class="app-root">
    <raft-test-ui></raft-test-ui>
    <xm-rate></xm-rate>
   </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'raft-core-demo';
}
